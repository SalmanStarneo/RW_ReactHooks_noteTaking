import './App.css';
import ListOfNotes from './components/ListOfNotes';
import './components/NotePad'
import NotePad from './components/NotePad';

function App() {
  return (
    <div className="App">
      <ListOfNotes/>
    </div>
  );
}

export default App;
