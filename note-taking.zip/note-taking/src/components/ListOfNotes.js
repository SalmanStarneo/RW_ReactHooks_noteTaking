import React,{useState} from "react";
import NotePad from "./NotePad";
import Note from "./Note";

function ListOfNotes() {

    const [notes,setNotes]=useState([]);

    const addNote = note => {
        if(!note.text || /^\s*$/.test(note.text)){
            return;
        }
        note.color="orange";
        const newNotes = [note, ...notes];
        setNotes(newNotes);
    };

    const removeNote = id =>{
        const removeArray = [...notes].filter(note => note.id !== id);
        setNotes(removeArray);
    };

    const updateNote = (noteId, newValue) => { 
        if(!newValue.text || /^\s*$/.test(newValue.text)){
            return;
        }
        setNotes(previousNote => previousNote.map(item =>(item.id === noteId ? newValue : item)));
    };

    const completeNote = id =>{
        let updatedNotes = notes.map(note =>{
            if(note.id===id){
                note.isComplete = !note.isComplete;
            }
            return note;
        });
        setNotes(updatedNotes);
    };

    const changeColor = (newColor,id) =>{
        let colorNote = notes.map(current =>{

        if(current.id === id){
            current.color = newColor;
            console.log(newColor);
        }  
            return current;
        });
        setNotes(colorNote);
    };

    return(
        <div className="noteListContainer">
            <div className="notePad Header">
                <h1 className="title">\(^-^)/ Note-Book \(^-^)/</h1>
                <p>Create, save, and edit your notes in this minimalist note-taking Web-App</p>
            </div>
            <br/>
            <NotePad onSubmit={addNote}
            />
            <Note notes={notes} 
            completeNote={completeNote} updateNote={updateNote} removeNote={removeNote} colorChange={changeColor}/>
        </div>
    );
    
}

export default ListOfNotes;