import React,{useState} from "react";
import NotePad from "./NotePad";
import {RiCloseCircleLine} from "react-icons/ri";
import {TiEdit} from "react-icons/ti";

function Note({notes,completeNote, removeNote, updateNote,colorChange}){
    const [edit, setEdit] = useState({
        id:null,
        value:''
    });

    const submitUpdate = value =>{
        updateNote(edit.id, value);
        setEdit({
            id: null,
            value:''
        });
    }

    if(edit.id){
        return(<div className="Form">
            <NotePad edit={edit} onSubmit={submitUpdate}/>
            <br/>
            <p className="Notification">Click Save Note again to save Changes</p>
        </div>
        );
    };

    return notes.map((note, index)=>(
        <div className="notesContainer">

            <div
            key={index}
            className={`${note.color} ${note.isComplete ? 'note-row complete' : 'note-row'}`}
            >
                <div className="icons">
                <RiCloseCircleLine onClick={() => removeNote(note.id)} className="delete-icon"/>
                <TiEdit onClick={() => setEdit({id: note.id, value: note.text})} className="edit-icon"/>
                
                </div>
                <div className = "colorPalette">
                    <select id="colorPicker"  onChange = {(event) => colorChange(event.target.value,note.id)}>
                        <option value="blue">Blue</option>
                        <option value="green">Green</option>
                        <option value="yellow">Yellow</option>
                        <option value="purple">Purple</option> 
                        <option value="orange">Orange</option>
                    </select>
                </div>
                <br/>
                <div key={note.id} onClick={() => completeNote(note.id)}>
                    {note.text} 
                </div>
                

               
               
            </div>
        </div>
    ));
}

export default Note;