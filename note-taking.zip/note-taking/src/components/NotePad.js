import React, { useState, useEffect, useRef } from "react";
import Note from "./Note";

function NotePad(props){
    const [input, setInput] = useState('');

    const noteSubmitted = event =>{
        setInput(event.target.value);
    }

    const focusInput = useRef(null);

    useEffect(() => {
        focusInput.current.focus()
    })

    const submitController = event => {
        event.preventDefault();

        props.onSubmit({
            id: Math.round(Math.random()*4000),
            text: input
        });
        setInput('');
    };
   
    return( 
        <div className="notePad Form">
            <form className="notePad" onSubmit={submitController}>
                <input
                type="text"
                placeholder="Type in here"
                value={input}
                name="text"
                className="notePad"
                onChange={noteSubmitted}
                ref={focusInput}
                />
                <button className="saveButton">Save Note</button>
            </form>
        </div>
    );
    
}

export default NotePad;